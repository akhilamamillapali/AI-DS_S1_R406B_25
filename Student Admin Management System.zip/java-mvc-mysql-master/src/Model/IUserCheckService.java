package Model;


public interface IUserCheckService {
    public boolean checkUser(int id);
}
