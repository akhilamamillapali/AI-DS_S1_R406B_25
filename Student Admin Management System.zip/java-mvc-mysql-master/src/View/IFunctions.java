
package View;

public interface IFunctions {
    void delete();
    void ekle();
    void cikis_yap();
    void sifre_degistir();
}
