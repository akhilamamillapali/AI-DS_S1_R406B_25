# university-management-system

![test](https://user-images.githubusercontent.com/101992799/168947581-48f65b6f-311e-43ff-81e7-0fa5f945e4cc.gif)
